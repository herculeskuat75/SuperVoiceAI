package com.supervoice.ai

/** Status keyboard bersama; diisi oleh MainActivity & TypingAccessibilityService. */
object KeyboardState {
    @Volatile
    var visible: Boolean = false

    /** Callback tunggal yang dipicu saat status keyboard berubah (UI terkait cukup subscribe di sini). */
    @Volatile
    var listener: ((Boolean) -> Unit)? = null
}
