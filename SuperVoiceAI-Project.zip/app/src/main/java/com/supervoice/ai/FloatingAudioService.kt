package com.supervoice.ai

import android.annotation.SuppressLint
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.draw.scale
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import android.view.View
import android.view.WindowManager
import android.widget.ProgressBar
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import android.widget.TextView
import android.widget.Toast
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class FloatingAudioService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null

    private var mediaRecorder: MediaRecorder? = null
    private var audioFile: File? = null
    private var isRecording = false
    private var recStartMs = 0L
    private var peakAmp = 0
    private val ampPoller = object : Runnable {
        override fun run() {
            if (!isRecording) return
            try {
                val amp = mediaRecorder?.maxAmplitude ?: 0
                peakAmp = maxOf(peakAmp, amp)
                val now = System.currentTimeMillis()
                if (amp > 1500) lastVoiceMs = now
                if (now - recStartMs > 1200) {
                    showStatus(if (now - lastVoiceMs > 1000) "Menunggu suara..." else "Merekam...")
                }
            } catch (_: Exception) {}
            handler.postDelayed(this, 80)
        }
    }

    private lateinit var cvWave: ComposeView
    private var bubbleView: View? = null
    private var rippleView: ComposeView? = null
    private var idleGlowView: ComposeView? = null
    private val glowReach = mutableIntStateOf(0)
    private val isRecordingState = mutableStateOf(false)
    private val bubbleInteraction = MutableInteractionSource()
    private var currentPress: PressInteraction.Press? = null
    private val rainbowDps = mutableIntStateOf(120)
    private var overlayOwner: OverlayOwner? = null
    private val pressDepth = mutableIntStateOf(20)
    private val breathMs = mutableIntStateOf(3000)
    private val breathDepth = mutableIntStateOf(5)
    private val waterState = mutableStateOf(WaterConfig())
    private val prefsListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
        if (key == "rainbow_speed_dps") rainbowDps.intValue = p.getInt(key, 120).coerceIn(0, 3600)
        if (key == "breath_speed_ms") breathMs.intValue = p.getInt(key, 3000).coerceIn(500, 9000)
        if (key == "breath_depth") breathDepth.intValue = p.getInt(key, 5).coerceIn(0, 30)
        if (key != null && key.startsWith("idle_")) waterState.value = WaterConfig.from(p)
        if (key == "output_type_mode" && ::tvModeText.isInitialized) updateModeLabel(p.getBoolean(key, false))
        if (key == "glow_reach") { glowReach.intValue = p.getInt(key, 0).coerceIn(0, 100); handler.post { updateIdleGlow() } }
        if (key == "press_depth") pressDepth.intValue = p.getInt(key, 20).coerceIn(0, 60)
    }
    private var bubbleScale = 1f
    private var initialX = 0
    private var initialY = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pbLoading: ProgressBar
    private lateinit var tvStatusText: TextView
    private lateinit var tvModeText: TextView
    private lateinit var tvIdleText: TextView
    private var dropZoneView: View? = null
    private var dropZoneActive = false
    private var lastVoiceMs = 0L

    companion object {
        private const val BASE_DP = 90
        private const val MIN_SCALE = 0.05f
        private const val MAX_SCALE = 2.5f
        private const val DISMISS_PX = 150
    }

    private fun bubbleSizePx(): Int = (BASE_DP * resources.displayMetrics.density * bubbleScale).toInt()

    private fun applyBubbleSize() {
        val size = bubbleSizePx()
        listOfNotNull(bubbleView, cvWave).forEach { v ->
            val lp = v.layoutParams
            lp.width = size
            lp.height = size
            v.layoutParams = lp
        }
        if (::pbLoading.isInitialized) {
            val pbSize = (size * 0.4f).toInt().coerceAtLeast(1)
            val plp = pbLoading.layoutParams
            plp.width = pbSize
            plp.height = pbSize
            pbLoading.layoutParams = plp
        }
    }

    private fun realScreenHeight(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) windowManager.currentWindowMetrics.bounds.height()
        else android.util.DisplayMetrics().also {
            @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(it)
        }.heightPixels

    private fun updateModeLabel(typeMode: Boolean) {
        tvModeText.text = if (typeMode) "Mode Otomatis" else "Mode Manual"
    }

    private fun showDropZone() {
        if (dropZoneView != null) return
        val density = resources.displayMetrics.density
        val zoneH = (realScreenHeight() * 0.2f).toInt()
        val root = android.widget.FrameLayout(this)
        root.setBackgroundColor(0x66000000)
        val tv = TextView(this).apply {
            text = "✕"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 44f
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xCCE53935.toInt())
            }
        }
        val d = (72 * density).toInt()
        root.addView(tv, android.widget.FrameLayout.LayoutParams(d, d, Gravity.CENTER))
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, zoneH, layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START }
        try {
            windowManager.addView(root, lp)
            dropZoneView = root
        } catch (_: Exception) { dropZoneView = null }
    }

    private fun hideDropZone() {
        dropZoneView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        dropZoneView = null
    }

    private fun inDropZone(rawY: Float): Boolean = rawY > realScreenHeight() * 0.8f

    private fun dismissBubble() {
        hideDropZone()
        removeRipple()
        removeIdleGlow()
        try { floatingView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        floatingView = null
        stopSelf()
    }

    private fun showStatus(text: String?) {
        if (::tvIdleText.isInitialized) tvIdleText.visibility = if (text == null) View.VISIBLE else View.GONE
        if (text == null) tvStatusText.visibility = View.GONE
        else { tvStatusText.text = text; tvStatusText.visibility = View.VISIBLE }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundWithNotification()
        try {
            setupFloatingWidget()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal tampilkan bubble: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun startForegroundWithNotification() {
        val channelId = "supervoice_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "SuperVoice Overlay Active",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("SuperVoice AI Mengambang")
            .setContentText("Widget perekam suara siap digunakan di mana saja")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1001,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(1001, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupFloatingWidget() {
        floatingView = LayoutInflater.from(ContextThemeWrapper(this, R.style.Theme_SuperVoiceAI)).inflate(R.layout.layout_floating_bubble, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 200
            alpha = 1f
        }

        val bubbleContainer = floatingView!!.findViewById<View>(R.id.bubbleContainer)
        bubbleView = bubbleContainer
        cvWave = floatingView!!.findViewById(R.id.cvWave)
        pbLoading = floatingView!!.findViewById(R.id.pbLoading)
        tvStatusText = floatingView!!.findViewById(R.id.tvStatusText)
        tvModeText = floatingView!!.findViewById(R.id.tvModeText)
        tvIdleText = floatingView!!.findViewById(R.id.tvIdleText)

        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        rainbowDps.intValue = if (prefs.contains("rainbow_speed_dps")) prefs.getInt("rainbow_speed_dps", 120).coerceIn(0, 3600)
            else (360000 / prefs.getInt("rainbow_duration_ms", 3000).coerceIn(1000, 15000))
        breathMs.intValue = prefs.getInt("breath_speed_ms", 3000).coerceIn(500, 9000)
        breathDepth.intValue = prefs.getInt("breath_depth", 5).coerceIn(0, 30)
        waterState.value = WaterConfig.from(prefs)
        pressDepth.intValue = prefs.getInt("press_depth", 20).coerceIn(0, 60)
        updateModeLabel(prefs.getBoolean("output_type_mode", false))
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)

        val owner = OverlayOwner().also { overlayOwner = it }
        floatingView!!.setViewTreeLifecycleOwner(owner)
        floatingView!!.setViewTreeSavedStateRegistryOwner(owner)
        floatingView!!.setViewTreeViewModelStoreOwner(owner)
        bubbleScale = prefs.getFloat("bubble_scale", 1f).coerceIn(MIN_SCALE, MAX_SCALE)
        applyBubbleSize()
        var downX = 0
        var downY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var scaled = false
        var pinching = false
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        val scaleDetector = android.view.ScaleGestureDetector(this,
            object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(d: android.view.ScaleGestureDetector): Boolean {
                    pinching = true
                    scaled = true
                    return true
                }
                override fun onScale(d: android.view.ScaleGestureDetector): Boolean = false
                override fun onScaleEnd(d: android.view.ScaleGestureDetector) {
                    prefs.edit().putFloat("bubble_scale", bubbleScale).apply()
                }
            })
        // Matikan quick-scale (double-tap lalu geser 1 jari) yang bikin ukuran berubah/loncat saat digeser
        scaleDetector.isQuickScaleEnabled = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) scaleDetector.isStylusScaleEnabled = false
        var lastSpan = 0f
        fun spanOf(e: MotionEvent): Float = kotlin.math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
        val bubbleTouchHandler = View.OnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            // Cubit dua jari manual (lebih sensitif, tanpa batas jarak minimum bawaan detector)
            if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN && event.pointerCount == 2) lastSpan = spanOf(event)
            if (event.actionMasked == MotionEvent.ACTION_POINTER_UP) lastSpan = 0f
            if (event.actionMasked == MotionEvent.ACTION_MOVE && event.pointerCount >= 2) {
                val span = spanOf(event)
                if (lastSpan > 0f && span > 0f) {
                    val f = Math.pow((span / lastSpan).toDouble(), 4.0).toFloat().coerceIn(0.3f, 4f)
                    val old = bubbleSizePx()
                    bubbleScale = (bubbleScale * f).coerceIn(MIN_SCALE, MAX_SCALE)
                    val diff = bubbleSizePx() - old
                    if (diff != 0) {
                        params.x -= diff / 2
                        params.y -= diff / 2
                        applyBubbleSize()
                        try { windowManager.updateViewLayout(floatingView, params) } catch (_: Exception) {}
                    }
                    scaled = true
                }
                lastSpan = span
            }
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    scaled = false
                    pinching = false
                    val pr = PressInteraction.Press(Offset.Zero)
                    currentPress = pr
                    bubbleInteraction.tryEmit(pr)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!pinching && event.pointerCount == 1) {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (!moved && (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop)) moved = true
                        if (moved) {
                            params.x = initialX + (event.rawX - touchX).toInt()
                            params.y = initialY + (event.rawY - touchY).toInt()
                            try { windowManager.updateViewLayout(floatingView, params) } catch (_: Exception) {}
                            val inZone = inDropZone(event.rawY)
                            floatingView?.alpha = if (inZone) 0.4f else 1f
                            if (inZone) showDropZone() else hideDropZone()
                        }
                    }
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    // jari kedua turun: kunci geser sampai semua jari diangkat (cegah loncat ke jari lain)
                    pinching = true
                    moved = true
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    // setelah cubit selesai, jangan lanjut geser sampai jari diangkat semua
                    moved = true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    currentPress?.let { bubbleInteraction.tryEmit(PressInteraction.Release(it)) }
                    currentPress = null
                    floatingView?.alpha = 1f
                    val releasedInZone = dropZoneView != null && inDropZone(event.rawY)
                    hideDropZone()
                    if (event.actionMasked == MotionEvent.ACTION_UP) {
                        if (scaled) {
                            prefs.edit().putFloat("bubble_scale", bubbleScale).apply()
                        } else if (moved) {
                            if (releasedInZone) dismissBubble()
                        } else {
                            if (cvWave.visibility == View.VISIBLE) {
                                showRipple()
                                onBubbleClicked()
                            }
                        }
                    }
                    pinching = false
                }
            }
            true
        }
        cvWave.setOnTouchListener(bubbleTouchHandler)
        // Saat memproses, cvWave disembunyikan: container yang menerima sentuhan agar tetap bisa digeser/dicubit
        bubbleContainer.setOnTouchListener(bubbleTouchHandler)
        cvWave.setContent {
            val pressedNow by bubbleInteraction.collectIsPressedAsState()
            val idleTransition = rememberInfiniteTransition(label = "idle")
            val rawProgress by idleTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(breathMs.intValue, easing = FastOutSlowInEasing),
                    RepeatMode.Reverse
                ),
                label = "idleProgress"
            )
            // Sentuh/geser => berhenti halus ke 0; lepas => jalan lagi
            val idleGate by animateFloatAsState(if (pressedNow) 0f else 1f, tween(200), label = "idleGate")
            val animProgress = rawProgress * idleGate
            Box(Modifier.fillMaxSize().scale(1.0f + (animProgress * (breathDepth.intValue / 100f)))) {
                WaveBubble(
                    animProgress = animProgress,
                    isRecording = isRecordingState.value,
                    rainbowDps = rainbowDps.intValue,
                    pressDepthPct = pressDepth.intValue,
                    water = waterState.value,
                    interactionSource = bubbleInteraction
                )
            }
        }
        owner.resume()

        glowReach.intValue = prefs.getInt("glow_reach", 0).coerceIn(0, 100)
        updateIdleGlow()
        windowManager.addView(floatingView, params)
    }

    /** Overlay layar penuh (di bawah tombol, tidak bisa disentuh) untuk glow saat diam; hanya aktif bila slider > 0. */
    private fun updateIdleGlow() {
        if (glowReach.intValue <= 0 || floatingView == null) { removeIdleGlow(); return }
        if (idleGlowView != null) return
        val owner = overlayOwner ?: return
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(dm)
        val lp = WindowManager.LayoutParams(
            dm.widthPixels, dm.heightPixels, layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val cv = ComposeView(this)
        cv.setViewTreeLifecycleOwner(owner)
        cv.setViewTreeSavedStateRegistryOwner(owner)
        cv.setViewTreeViewModelStoreOwner(owner)
        val ov = IntArray(2)
        val bl = IntArray(2)
        cv.setContent {
            IdleGlowOverlay(
                centerProvider = {
                    val b = bubbleView
                    if (b == null) Offset.Zero else {
                        cv.getLocationOnScreen(ov)
                        b.getLocationOnScreen(bl)
                        Offset(bl[0] - ov[0] + b.width / 2f, bl[1] - ov[1] + b.height / 2f)
                    }
                },
                spreadPct = glowReach.intValue,
                cycleMs = breathMs.intValue * 2,
                buttonRadiusProvider = { (bubbleView?.width ?: 0) / 2f },
                interactionSource = bubbleInteraction
            )
        }
        try {
            windowManager.addView(cv, lp)
            idleGlowView = cv
        } catch (_: Exception) { idleGlowView = null }
    }

    private fun removeIdleGlow() {
        idleGlowView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        idleGlowView = null
    }

    private fun showRipple() {
        removeRipple()
        val bubble = bubbleView ?: return
        val owner = overlayOwner ?: return
        val loc = IntArray(2)
        bubble.getLocationOnScreen(loc)
        val cx = loc[0] + bubble.width / 2f
        val cy = loc[1] + bubble.height / 2f
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(dm)
        val lp = WindowManager.LayoutParams(
            dm.widthPixels,
            dm.heightPixels,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val center = mutableStateOf(Offset(cx, cy))
        val cv = ComposeView(this)
        cv.setViewTreeLifecycleOwner(owner)
        cv.setViewTreeSavedStateRegistryOwner(owner)
        cv.setViewTreeViewModelStoreOwner(owner)
        val waterMs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
            .getInt("water_duration_ms", 1000).coerceIn(400, 9000)
        val amount = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
            .getInt("water_amount", 55).coerceIn(10, 100)
        val spread = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
            .getInt("water_reach", 0).coerceIn(0, 100)
        cv.setContent { RippleBurst(center.value, waterMs, amount, spread) { handler.post { removeRipple() } } }
        try {
            windowManager.addView(cv, lp)
            rippleView = cv
            cv.post {
                val l = IntArray(2)
                cv.getLocationOnScreen(l)
                center.value = Offset(cx - l[0], cy - l[1])
            }
        } catch (_: Exception) { rippleView = null }
    }

    private fun removeRipple() {
        rippleView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        rippleView = null
    }

    private fun onBubbleClicked() {
        if (!isRecording) {
            startRecording()
        } else {
            stopRecordingAndProcess()
        }
    }

    private fun startRecording() {
        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""

        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Masukkan API Key di aplikasi utama terlebih dahulu!", Toast.LENGTH_LONG).show()
            return
        }

        try {
            audioFile = File(cacheDir, "speech_temp.m4a")
            if (audioFile!!.exists()) audioFile!!.delete()

            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(audioFile!!.absolutePath)
                prepare()
                start()
            }

            isRecording = true
            recStartMs = System.currentTimeMillis()
            peakAmp = 0
            handler.post(ampPoller)
            isRecordingState.value = true
            lastVoiceMs = recStartMs
            showStatus("Merekam...")
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal rekam: ${e.message}", Toast.LENGTH_SHORT).show()
            resetBubbleState()
        }
    }

    private fun stopRecordingAndProcess() {
        var stopOk = true
        try { peakAmp = maxOf(peakAmp, mediaRecorder?.maxAmplitude ?: 0) } catch (_: Exception) {}
        val elapsed = System.currentTimeMillis() - recStartMs
        try {
            mediaRecorder?.stop()
        } catch (_: Exception) {
            stopOk = false
        }
        mediaRecorder?.release()
        mediaRecorder = null
        isRecording = false
        isRecordingState.value = false
        if (!stopOk) {
            Toast.makeText(this, "Rekaman terlalu singkat, coba lagi", Toast.LENGTH_SHORT).show()
            resetBubbleState()
            return
        }

        // Hening / terlalu singkat: jangan kirim ke AI (mencegah teks ngawur hasil halusinasi)
        val fileSize = audioFile?.length() ?: 0L
        if (elapsed < 1000 || peakAmp < 1000 || fileSize < 2048L) {
            Toast.makeText(this, "Tidak ada suara terdeteksi", Toast.LENGTH_SHORT).show()
            try { audioFile?.delete() } catch (_: Exception) {}
            resetBubbleState()
            return
        }

        // Update UI ke mode Loading
        cvWave.visibility = View.GONE
        pbLoading.visibility = View.VISIBLE
        showStatus("Memproses...")

        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        val apiKeyTranskripsi = prefs.getString("api_key", "").orEmpty()
        val apiKeyKoreksi = prefs.getString("api_key_koreksi", "").orEmpty()
        val isGroq = prefs.getBoolean("is_groq", true)
        val autoCorrect = prefs.getBoolean("auto_correct", true)

        serviceScope.launch {
            try {
                val resultText = AudioTranscriber.transcribeAndPolish(
                    audioFile = audioFile!!,
                    apiKey = apiKeyTranskripsi,
                    apiKeyKoreksi = apiKeyKoreksi,
                    isGroq = isGroq,
                    enableAutoCorrection = autoCorrect
                )

                val typeMode = prefs.getBoolean("output_type_mode", false)
                val noSpeech = resultText.isBlank() || resultText.trim().startsWith("(Tidak ada suara")
                if (noSpeech) {
                    // Hening / tanpa hasil: JANGAN salin apa pun ke Clipboard
                    Toast.makeText(this@FloatingAudioService, "Tidak ada suara terdeteksi", Toast.LENGTH_SHORT).show()
                } else if (typeMode) {
                    // Mode otomatis: tempel langsung via Aksesibilitas, tanpa menyentuh Clipboard
                    if (TypingAccessibilityService.typeText(resultText)) {
                        Toast.makeText(this@FloatingAudioService, "Selesai, teks diketik", Toast.LENGTH_SHORT).show()
                    } else {
                        showFailDialog(resultText)
                    }
                } else if (isJunkText(resultText)) {
                    Toast.makeText(this@FloatingAudioService, "Tidak ada suara terdeteksi", Toast.LENGTH_SHORT).show()
                } else {
                    copyToClipboard(resultText)
                    Toast.makeText(this@FloatingAudioService, "Tersalin ke Clipboard!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@FloatingAudioService, "Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            } finally {
                resetBubbleState()
            }
        }
    }

    /** True bila kosong / hanya tanda baca / simbol / emoji (tidak ada huruf atau angka). */
    private fun isJunkText(text: String): Boolean =
        text.replace(Regex("[\\p{P}\\p{S}\\p{Z}\\p{C}\\p{M}\\s]"), "").isEmpty()

    private fun copyToClipboard(text: String) {
        if (isJunkText(text)) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Super Voice AI", text))
    }

    private var failDialog: androidx.appcompat.app.AlertDialog? = null

    /** Mode otomatis gagal (tidak ada kolom input / keyboard tertutup): tanya pengguna. */
    private fun showFailDialog(text: String) {
        try {
            failDialog?.dismiss()
            val ctx = ContextThemeWrapper(this, R.style.Theme_SuperVoiceAI)
            val dlg = androidx.appcompat.app.AlertDialog.Builder(ctx)
                .setTitle("Kolom input tidak ditemukan")
                .setMessage("Teks tidak bisa diketik otomatis. Simpan ke Clipboard?")
                .setNegativeButton("Batal") { d, _ -> d.dismiss() }
                .setPositiveButton("Simpan ke Clipboard") { d, _ ->
                    copyToClipboard(text)
                    Toast.makeText(this, "Tersalin ke Clipboard!", Toast.LENGTH_SHORT).show()
                    d.dismiss()
                }
                .create()
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            dlg.window?.setType(type)
            dlg.show()
            failDialog = dlg
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal mengetik. Teks tidak disalin.", Toast.LENGTH_LONG).show()
        }
    }

    private fun resetBubbleState() {
        cvWave.visibility = View.VISIBLE
        isRecordingState.value = false
        pbLoading.visibility = View.GONE
        showStatus(null)
    }

    override fun onDestroy() {
        try { failDialog?.dismiss() } catch (_: Exception) {}
        serviceScope.cancel()
        mediaRecorder?.release()
        try { getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)
        hideDropZone()
        removeRipple()
        removeIdleGlow()
        try { floatingView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        overlayOwner?.destroy()
        super.onDestroy()
    }
}
