package com.supervoice.ai

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import android.view.View
import android.view.WindowManager
import android.widget.ProgressBar
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import android.widget.TextView
import android.widget.Toast
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class FloatingAudioService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null

    private var mediaRecorder: MediaRecorder? = null
    private var audioFile: File? = null
    private var isRecording = false

    private lateinit var cvWave: ComposeView
    private var bubbleView: View? = null
    private var rippleView: ComposeView? = null
    private val isRecordingState = mutableStateOf(false)
    private val bubbleInteraction = MutableInteractionSource()
    private var currentPress: PressInteraction.Press? = null
    private val rainbowMs = mutableIntStateOf(3000)
    private var overlayOwner: OverlayOwner? = null
    private val prefsListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
        if (key == "rainbow_duration_ms") rainbowMs.intValue = p.getInt(key, 3000).coerceIn(1000, 5000)
    }
    private var bubbleScale = 1f
    private var initialX = 0
    private var initialY = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pbLoading: ProgressBar
    private lateinit var tvStatusText: TextView
    private lateinit var cardResult: View
    private lateinit var tvResultContent: TextView

    companion object {
        private const val BASE_DP = 90
        private const val MIN_SCALE = 0.6f
        private const val MAX_SCALE = 2.5f
        private const val DISMISS_PX = 150
    }

    private fun bubbleSizePx(): Int = (BASE_DP * resources.displayMetrics.density * bubbleScale).toInt()

    private fun applyBubbleSize() {
        val size = bubbleSizePx()
        listOfNotNull(bubbleView, cvWave).forEach { v ->
            val lp = v.layoutParams
            lp.width = size
            lp.height = size
            v.layoutParams = lp
        }
    }

    private fun realScreenHeight(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) windowManager.currentWindowMetrics.bounds.height()
        else android.util.DisplayMetrics().also {
            @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(it)
        }.heightPixels

    private fun dismissBubble() {
        removeRipple()
        try { floatingView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        floatingView = null
        stopSelf()
    }

    private fun showStatus(text: String?) {
        if (text == null) tvStatusText.visibility = View.GONE
        else { tvStatusText.text = text; tvStatusText.visibility = View.VISIBLE }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundWithNotification()
        try {
            setupFloatingWidget()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal tampilkan bubble: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun startForegroundWithNotification() {
        val channelId = "supervoice_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "SuperVoice Overlay Active",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("SuperVoice AI Mengambang")
            .setContentText("Widget perekam suara siap digunakan di mana saja")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1001,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(1001, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupFloatingWidget() {
        floatingView = LayoutInflater.from(ContextThemeWrapper(this, R.style.Theme_SuperVoiceAI)).inflate(R.layout.layout_floating_bubble, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 200
        }

        val bubbleContainer = floatingView!!.findViewById<View>(R.id.bubbleContainer)
        bubbleView = bubbleContainer
        cvWave = floatingView!!.findViewById(R.id.cvWave)
        pbLoading = floatingView!!.findViewById(R.id.pbLoading)
        tvStatusText = floatingView!!.findViewById(R.id.tvStatusText)
        cardResult = floatingView!!.findViewById(R.id.cardResult)
        tvResultContent = floatingView!!.findViewById(R.id.tvResultContent)

        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        rainbowMs.intValue = prefs.getInt("rainbow_duration_ms", 3000).coerceIn(1000, 5000)
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)

        val owner = OverlayOwner().also { overlayOwner = it }
        floatingView!!.setViewTreeLifecycleOwner(owner)
        floatingView!!.setViewTreeSavedStateRegistryOwner(owner)
        floatingView!!.setViewTreeViewModelStoreOwner(owner)
        bubbleScale = prefs.getFloat("bubble_scale", 1f).coerceIn(MIN_SCALE, MAX_SCALE)
        applyBubbleSize()
        var downX = 0
        var downY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var scaled = false
        var pinching = false
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        val scaleDetector = android.view.ScaleGestureDetector(this,
            object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(d: android.view.ScaleGestureDetector): Boolean {
                    pinching = true
                    scaled = true
                    return true
                }
                override fun onScale(d: android.view.ScaleGestureDetector): Boolean {
                    val old = bubbleSizePx()
                    bubbleScale = (bubbleScale * d.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
                    val diff = bubbleSizePx() - old
                    params.x -= diff / 2
                    params.y -= diff / 2
                    applyBubbleSize()
                    try { windowManager.updateViewLayout(floatingView, params) } catch (_: Exception) {}
                    return true
                }
                override fun onScaleEnd(d: android.view.ScaleGestureDetector) {
                    prefs.edit().putFloat("bubble_scale", bubbleScale).apply()
                }
            })
        cvWave.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    scaled = false
                    pinching = false
                    val pr = PressInteraction.Press(Offset.Zero)
                    currentPress = pr
                    bubbleInteraction.tryEmit(pr)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!pinching && event.pointerCount == 1) {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (!moved && (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop)) moved = true
                        if (moved) {
                            params.x = initialX + (event.rawX - touchX).toInt()
                            params.y = initialY + (event.rawY - touchY).toInt()
                            try { windowManager.updateViewLayout(floatingView, params) } catch (_: Exception) {}
                        }
                    }
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    // setelah cubit selesai, jangan lanjut geser sampai jari diangkat semua
                    moved = true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    currentPress?.let { bubbleInteraction.tryEmit(PressInteraction.Release(it)) }
                    currentPress = null
                    if (event.actionMasked == MotionEvent.ACTION_UP) {
                        if (scaled) {
                            prefs.edit().putFloat("bubble_scale", bubbleScale).apply()
                        } else if (moved) {
                            if (params.y > realScreenHeight() - 200) dismissBubble()
                        } else {
                            showRipple()
                            onBubbleClicked()
                        }
                    }
                    pinching = false
                }
            }
            true
        }
        cvWave.setContent {
            Box(Modifier.fillMaxSize()) {
                WaveBubble(
                    isRecording = isRecordingState.value,
                    durationMs = rainbowMs.intValue,
                    interactionSource = bubbleInteraction
                )
            }
        }
        owner.resume()

        cardResult.setOnClickListener {
            cardResult.visibility = View.GONE
        }

        windowManager.addView(floatingView, params)
    }

    private fun showRipple() {
        removeRipple()
        val bubble = bubbleView ?: return
        val owner = overlayOwner ?: return
        val loc = IntArray(2)
        bubble.getLocationOnScreen(loc)
        val cx = loc[0] + bubble.width / 2f
        val cy = loc[1] + bubble.height / 2f
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val center = mutableStateOf(Offset(cx, cy))
        val cv = ComposeView(this)
        cv.setViewTreeLifecycleOwner(owner)
        cv.setViewTreeSavedStateRegistryOwner(owner)
        cv.setViewTreeViewModelStoreOwner(owner)
        val waterMs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
            .getInt("water_duration_ms", 1200).coerceIn(400, 3000)
        cv.setContent { RippleBurst(center.value, waterMs) { handler.post { removeRipple() } } }
        try {
            windowManager.addView(cv, lp)
            rippleView = cv
            cv.post {
                val l = IntArray(2)
                cv.getLocationOnScreen(l)
                center.value = Offset(cx - l[0], cy - l[1])
            }
        } catch (_: Exception) { rippleView = null }
    }

    private fun removeRipple() {
        rippleView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        rippleView = null
    }

    private fun onBubbleClicked() {
        if (!isRecording) {
            startRecording()
        } else {
            stopRecordingAndProcess()
        }
    }

    private fun startRecording() {
        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""

        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Masukkan API Key di aplikasi utama terlebih dahulu!", Toast.LENGTH_LONG).show()
            return
        }

        try {
            audioFile = File(cacheDir, "speech_temp.m4a")
            if (audioFile!!.exists()) audioFile!!.delete()

            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(audioFile!!.absolutePath)
                prepare()
                start()
            }

            isRecording = true
            isRecordingState.value = true
            showStatus("Mulai Merekam...")
            handler.postDelayed({ if (isRecording) showStatus("Merekam...") }, 1200)
            cardResult.visibility = View.GONE
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal rekam: ${e.message}", Toast.LENGTH_SHORT).show()
            resetBubbleState()
        }
    }

    private fun stopRecordingAndProcess() {
        var stopOk = true
        try {
            mediaRecorder?.stop()
        } catch (_: Exception) {
            stopOk = false
        }
        mediaRecorder?.release()
        mediaRecorder = null
        isRecording = false
        isRecordingState.value = false
        if (!stopOk) {
            Toast.makeText(this, "Rekaman terlalu singkat, coba lagi", Toast.LENGTH_SHORT).show()
            resetBubbleState()
            return
        }

        // Update UI ke mode Loading
        cvWave.visibility = View.GONE
        pbLoading.visibility = View.VISIBLE
        showStatus("Memproses...")

        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "").orEmpty()
        val isGroq = prefs.getBoolean("is_groq", true)
        val autoCorrect = prefs.getBoolean("auto_correct", true)

        serviceScope.launch {
            try {
                val resultText = AudioTranscriber.transcribeAndPolish(
                    audioFile = audioFile!!,
                    apiKey = apiKey,
                    isGroq = isGroq,
                    enableAutoCorrection = autoCorrect
                )

                val typeMode = prefs.getBoolean("output_type_mode", false)
                var typed = false
                if (typeMode) typed = TypingAccessibilityService.typeText(resultText)
                if (!typed) {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Super Voice AI", resultText))
                    Toast.makeText(
                        this@FloatingAudioService,
                        if (typeMode) "Tidak ada kolom input aktif / Aksesibilitas mati. Tersalin ke Clipboard." else "Tersalin ke Clipboard!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                floatingView?.findViewById<TextView>(R.id.tvResultLabel)?.text =
                    if (typed) "Diketik Otomatis:" else "Otomatis Disalin (Tinggal Tempel):"

                // Tampilkan hasil di widget pop-up
                tvResultContent.text = resultText
                cardResult.visibility = View.VISIBLE
                floatingView?.let { v ->
                    try { windowManager.updateViewLayout(v, v.layoutParams) } catch (_: Exception) {}
                }

                // Auto-hide popup setelah 7 detik
                Handler(Looper.getMainLooper()).postDelayed({
                    cardResult.visibility = View.GONE
                }, 7000)

            } catch (e: Exception) {
                Toast.makeText(this@FloatingAudioService, "Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            } finally {
                resetBubbleState()
            }
        }
    }

    private fun resetBubbleState() {
        cvWave.visibility = View.VISIBLE
        isRecordingState.value = false
        pbLoading.visibility = View.GONE
        showStatus(null)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        mediaRecorder?.release()
        try { getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)
        removeRipple()
        try { floatingView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        overlayOwner?.destroy()
        super.onDestroy()
    }
}
