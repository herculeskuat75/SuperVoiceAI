package com.supervoice.ai

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class FloatingAudioService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null

    private var mediaRecorder: MediaRecorder? = null
    private var audioFile: File? = null
    private var isRecording = false

    private lateinit var ivMicIcon: ImageView
    private lateinit var pbLoading: ProgressBar
    private lateinit var tvStatusText: TextView
    private lateinit var cardResult: View
    private lateinit var tvResultContent: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundWithNotification()
        setupFloatingWidget()
    }

    private fun startForegroundWithNotification() {
        val channelId = "supervoice_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "SuperVoice Overlay Active",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("SuperVoice AI Mengambang")
            .setContentText("Widget perekam suara siap digunakan di mana saja")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1001,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(1001, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupFloatingWidget() {
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_bubble, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 200
        }

        windowManager.addView(floatingView, params)

        val bubbleContainer = floatingView!!.findViewById<View>(R.id.bubbleContainer)
        ivMicIcon = floatingView!!.findViewById(R.id.ivMicIcon)
        pbLoading = floatingView!!.findViewById(R.id.pbLoading)
        tvStatusText = floatingView!!.findViewById(R.id.tvStatusText)
        cardResult = floatingView!!.findViewById(R.id.cardResult)
        tvResultContent = floatingView!!.findViewById(R.id.tvResultContent)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = true

        bubbleContainer.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
                        isClick = false
                        params.x = initialX + deltaX
                        params.y = initialY + deltaY
                        windowManager.updateViewLayout(floatingView, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        onBubbleClicked()
                    }
                    true
                }
                else -> false
            }
        }

        cardResult.setOnClickListener {
            cardResult.visibility = View.GONE
        }
    }

    private fun onBubbleClicked() {
        if (!isRecording) {
            startRecording()
        } else {
            stopRecordingAndProcess()
        }
    }

    private fun startRecording() {
        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""

        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Masukkan API Key di aplikasi utama terlebih dahulu!", Toast.LENGTH_LONG).show()
            return
        }

        try {
            audioFile = File(cacheDir, "speech_temp.m4a")
            if (audioFile!!.exists()) audioFile!!.delete()

            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(audioFile!!.absolutePath)
                prepare()
                start()
            }

            isRecording = true
            ivMicIcon.setColorFilter(android.graphics.Color.RED)
            tvStatusText.text = "Merekam..."
            cardResult.visibility = View.GONE
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal rekam: ${e.message}", Toast.LENGTH_SHORT).show()
            resetBubbleState()
        }
    }

    private fun stopRecordingAndProcess() {
        try {
            mediaRecorder?.stop()
        } catch (_: Exception) {}
        mediaRecorder?.release()
        mediaRecorder = null
        isRecording = false

        // Update UI ke mode Loading
        ivMicIcon.visibility = View.GONE
        pbLoading.visibility = View.VISIBLE
        tvStatusText.text = "Memproses..."

        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "").orEmpty()
        val isGroq = prefs.getBoolean("is_groq", true)
        val autoCorrect = prefs.getBoolean("auto_correct", true)

        serviceScope.launch {
            try {
                val resultText = AudioTranscriber.transcribeAndPolish(
                    audioFile = audioFile!!,
                    apiKey = apiKey,
                    isGroq = isGroq,
                    enableAutoCorrection = autoCorrect
                )

                // Otomatis salin ke clipboard
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("SuperVoice AI", resultText)
                clipboard.setPrimaryClip(clip)

                Toast.makeText(this@FloatingAudioService, "Tersalin ke Clipboard!", Toast.LENGTH_SHORT).show()

                // Tampilkan hasil di widget pop-up
                tvResultContent.text = resultText
                cardResult.visibility = View.VISIBLE

                // Auto-hide popup setelah 7 detik
                Handler(Looper.getMainLooper()).postDelayed({
                    cardResult.visibility = View.GONE
                }, 7000)

            } catch (e: Exception) {
                Toast.makeText(this@FloatingAudioService, "Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            } finally {
                resetBubbleState()
            }
        }
    }

    private fun resetBubbleState() {
        ivMicIcon.visibility = View.VISIBLE
        ivMicIcon.clearColorFilter()
        pbLoading.visibility = View.GONE
        tvStatusText.text = "Ketuk"
    }

    override fun onDestroy() {
        serviceScope.cancel()
        mediaRecorder?.release()
        floatingView?.let { windowManager.removeView(it) }
        super.onDestroy()
    }
}
