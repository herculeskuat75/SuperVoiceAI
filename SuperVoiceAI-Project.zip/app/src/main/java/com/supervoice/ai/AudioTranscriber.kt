package com.supervoice.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object AudioTranscriber {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Mentranskripsikan audio rekaman menggunakan Groq Whisper-Large-V3 (Super Cepat & Paling Akurat)
     * atau OpenAI Whisper-1, lalu mengoreksinya dengan AI agar bebas typo & alami seperti gaya Claude.
     */
    suspend fun transcribeAndPolish(
        audioFile: File,
        apiKey: String,
        isGroq: Boolean,
        enableAutoCorrection: Boolean
    ): String = withContext(Dispatchers.IO) {
        if (!audioFile.exists() || audioFile.length() == 0L) {
            throw Exception("File rekaman kosong atau gagal disimpan.")
        }

        val baseUrl = if (isGroq) "https://api.groq.com/openai/v1" else "https://api.openai.com/v1"
        val whisperModel = if (isGroq) "whisper-large-v3" else "whisper-1"
        val chatModel = if (isGroq) "llama-3.3-70b-versatile" else "gpt-4o-mini"

        // 1. Kirim file audio ke endpoint Transcriptions (Whisper)
        val fileBody = audioFile.asRequestBody("audio/mp4".toMediaTypeOrNull())
        val multipartBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", audioFile.name, fileBody)
            .addFormDataPart("model", whisperModel)
            .addFormDataPart("response_format", "json")
            .build()

        val sttRequest = Request.Builder()
            .url("$baseUrl/audio/transcriptions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(multipartBody)
            .build()

        val rawText: String = client.newCall(sttRequest).execute().use { response ->
            val resStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw Exception("Gagal Transkripsi (${response.code}): $resStr")
            }
            val json = try { JSONObject(resStr) } catch (e: Exception) {
                throw Exception("Respons API tidak valid: $resStr")
            }
            json.optString("text", "").trim()
        }

        if (rawText.isEmpty()) {
            return@withContext "(Tidak ada suara terdeteksi)"
        }

        if (!enableAutoCorrection) {
            return@withContext rawText
        }

        // 2. Koreksi & Poles Kalimat dengan AI (Claude Prompting Style)
        val systemPrompt = "Kamu adalah editor teks dan ahli bahasa jenius setingkat Claude AI. " +
                "Tugasmu: Perbaiki kata-kata hasil transkripsi audio berikut jika ada salah dengar, typo, gumaman kata terbata-bata, " +
                "serta bubuhkan tanda baca dan kapitalisasi yang sempurna. " +
                "Pertahankan maksud asli pembicara. PENTING: Kembalikan HANYA teks yang telah diperbaiki tanpa salam, intro, atau catatan apa pun."

        val payload = JSONObject().apply {
            put("model", chatModel)
            put("temperature", 0.2)
            val messages = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemPrompt)
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", rawText)
                })
            }
            put("messages", messages)
        }

        val chatRequest = Request.Builder()
            .url("$baseUrl/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaTypeOrNull()))
            .build()

        client.newCall(chatRequest).execute().use { response ->
            val resStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                // Fallback ke hasil teks mentah jika endpoint chat gagal
                return@withContext rawText
            }
            val json = JSONObject(resStr)
            val choices = json.optJSONArray("choices")
            if (choices != null && choices.length() > 0) {
                val message = choices.getJSONObject(0).optJSONObject("message")
                val refined = message?.optString("content", "")?.trim().orEmpty()
                if (refined.isNotEmpty()) refined else rawText
            } else {
                rawText
            }
        }
    }
}
