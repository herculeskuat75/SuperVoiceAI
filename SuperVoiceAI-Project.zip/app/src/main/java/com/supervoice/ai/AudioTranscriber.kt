package com.supervoice.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object AudioTranscriber {

    private val hallucinations = listOf(
        "terima kasih telah menonton", "terima kasih sudah menonton", "thanks for watching",
        "thank you for watching", "subtitle by", "subtitles by", "amara.org", "terima kasih atas perhatiannya",
        "jangan lupa subscribe", "sampai jumpa di video berikutnya", "subtitle oleh", "transcribed by"
    )

    /** Buang segmen yang kemungkinan besar bukan ucapan (halusinasi Whisper saat hening/noise). */
    private fun filterSpeech(json: JSONObject): String {
        val segs = json.optJSONArray("segments")
        val text: String = if (segs != null && segs.length() > 0) {
            val sb = StringBuilder()
            for (i in 0 until segs.length()) {
                val sg = segs.getJSONObject(i)
                val noSpeech = sg.optDouble("no_speech_prob", 0.0)
                val logProb = sg.optDouble("avg_logprob", 0.0)
                val comp = sg.optDouble("compression_ratio", 1.0)
                if (noSpeech > 0.55 && logProb < -0.7) continue
                if (logProb < -1.3 || comp > 2.4) continue
                sb.append(sg.optString("text", "")).append(' ')
            }
            sb.toString().trim()
        } else json.optString("text", "").trim()
        val low = text.lowercase()
        if (hallucinations.any { low.contains(it) } && text.length < 80) return ""
        return text
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Mentranskripsikan audio rekaman menggunakan Groq Whisper-Large-V3 (Super Cepat & Paling Akurat)
     * atau OpenAI Whisper-1, lalu mengoreksinya dengan AI agar bebas typo & alami seperti gaya Claude.
     */
    suspend fun transcribeAndPolish(
        audioFile: File,
        apiKey: String,
        apiKeyKoreksi: String,
        isGroq: Boolean,
        enableAutoCorrection: Boolean
    ): String = withContext(Dispatchers.IO) {
        if (!audioFile.exists() || audioFile.length() == 0L) {
            throw Exception("File rekaman kosong atau gagal disimpan.")
        }

        val baseUrl = if (isGroq) "https://api.groq.com/openai/v1" else "https://api.openai.com/v1"
        val whisperModel = if (isGroq) "whisper-large-v3" else "whisper-1"

        // 1. Kirim file audio ke endpoint Transcriptions (Whisper)
        val fileBody = audioFile.asRequestBody("audio/mp4".toMediaTypeOrNull())
        val multipartBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", audioFile.name, fileBody)
            .addFormDataPart("model", whisperModel)
            .addFormDataPart("response_format", "verbose_json")
            .addFormDataPart("temperature", "0")
            .build()

        val sttRequest = Request.Builder()
            .url("$baseUrl/audio/transcriptions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(multipartBody)
            .build()

        val rawText: String = client.newCall(sttRequest).execute().use { response ->
            val resStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw Exception("Gagal Transkripsi (${response.code}): $resStr")
            }
            val json = try { JSONObject(resStr) } catch (e: Exception) {
                throw Exception("Respons API tidak valid: $resStr")
            }
            filterSpeech(json)
        }

        if (rawText.isEmpty()) {
            return@withContext "(Tidak ada suara terdeteksi)"
        }

        if (!enableAutoCorrection || apiKeyKoreksi.isBlank()) {
            return@withContext rawText
        }

        // 2. Koreksi teks dengan Gemini Flash (fallback ke teks asli jika error)
        try {
            val systemPrompt = "Kamu adalah asisten penyunting teks profesional. Perbaiki tata bahasa, ejaan, dan tanda baca dari teks berikut. Pertahankan gaya bahasa santai namun tetap rapi, dan jangan mengubah makna aslinya."
            val payload = JSONObject().apply {
                put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                put("contents", JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", rawText)))))
                put("generationConfig", JSONObject().put("temperature", 0))
            }
            val chatRequest = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent")
                .addHeader("x-goog-api-key", apiKeyKoreksi.trim())
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                .build()

            client.newCall(chatRequest).execute().use { response ->
                val resStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) return@withContext rawText
                val refined = JSONObject(resStr).optJSONArray("candidates")
                    ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    ?.optJSONObject(0)?.optString("text", "")?.trim().orEmpty()
                if (refined.isNotEmpty() && refined.length <= rawText.length * 1.6 + 20) refined else rawText
            }
        } catch (e: Exception) {
            rawText
        }
    }
}
