package com.supervoice.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.max
import kotlin.math.min

class TypingAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TypingAccessibilityService? = null

        /** Mengetik teks ke kolom input yang sedang fokus. Return false jika gagal. */
        fun typeText(text: String): Boolean = instance?.insert(text) ?: false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            val imeShown = windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
            if (imeShown != KeyboardState.visible) {
                KeyboardState.visible = imeShown
                KeyboardState.listener?.invoke(imeShown)
            }
        } catch (_: Exception) {}
    }

    /** Cari node input yang fokus: jendela aktif dulu, lalu semua jendela non-IME. */
    private fun findFocusedInput(): AccessibilityNodeInfo? {
        rootInActiveWindow?.let { r ->
            (r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: r.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY))?.let { return it }
        }
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) continue
                val r = w.root ?: continue
                r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.let { if (it.isEditable) return it }
            }
        } catch (_: Exception) {}
        return null
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    private fun insert(text: String): Boolean {
        val node = findFocusedInput() ?: return false
        if (!node.isEditable) return false

        val current = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        var s = node.textSelectionStart
        var e = node.textSelectionEnd
        if (s < 0 || e < 0) { s = current.length; e = s }
        val start = min(s, e).coerceIn(0, current.length)
        val end = max(s, e).coerceIn(0, current.length)

        val newText = current.substring(0, start) + text + current.substring(end)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
        }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok) {
            val pos = start + text.length
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, pos)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, pos)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        }
        return ok
    }
}
