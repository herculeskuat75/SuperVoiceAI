package com.supervoice.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.max
import kotlin.math.min

class TypingAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TypingAccessibilityService? = null

        /** Mengetik teks ke kolom input yang sedang fokus. Return false jika gagal. */
        fun typeText(text: String): Boolean = instance?.insert(text) ?: false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            val imeShown = windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
            if (imeShown != KeyboardState.visible) {
                KeyboardState.visible = imeShown
                KeyboardState.listener?.invoke(imeShown)
            }
        } catch (_: Exception) {}
    }

    /** Telusuri rekursif semua anak; kumpulkan node yang bisa diedit. */
    private fun collectEditable(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (node == null || depth > 60) return
        try {
            val cls = node.className?.toString().orEmpty()
            if ((node.isEditable || cls == "android.widget.EditText") && node.isEnabled) out.add(node)
            for (i in 0 until node.childCount) collectEditable(node.getChild(i), out, depth + 1)
        } catch (_: Exception) {}
    }

    /** Cari kolom input: traverse root jendela aktif, lalu semua jendela non-IME & bukan aplikasi ini. */
    private fun findInputNode(): AccessibilityNodeInfo? {
        val roots = mutableListOf<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { if (it.packageName != packageName) roots.add(it) }
        try {
            for (w in windows.sortedByDescending { it.layer }) {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) continue
                val r = w.root ?: continue
                if (r.packageName == packageName) continue
                roots.add(r)
            }
        } catch (_: Exception) {}

        val all = mutableListOf<AccessibilityNodeInfo>()
        for (r in roots) {
            val found = mutableListOf<AccessibilityNodeInfo>()
            collectEditable(r, found)
            // Utamakan yang fokus di root ini; kalau ada langsung pakai
            found.firstOrNull { it.isFocused || it.isAccessibilityFocused }?.let { return it }
            all.addAll(found)
        }
        return all.firstOrNull { it.isVisibleToUser } ?: all.firstOrNull()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    private fun insert(text: String): Boolean {
        val node = findInputNode() ?: return false

        val current = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        var s = node.textSelectionStart
        var e = node.textSelectionEnd
        if (s < 0 || e < 0) { s = current.length; e = s }
        val start = min(s, e).coerceIn(0, current.length)
        val end = max(s, e).coerceIn(0, current.length)

        val newText = current.substring(0, start) + text + current.substring(end)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
        }
        var ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!ok) {
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        if (ok) {
            val pos = start + text.length
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, pos)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, pos)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        }
        return ok
    }
}
