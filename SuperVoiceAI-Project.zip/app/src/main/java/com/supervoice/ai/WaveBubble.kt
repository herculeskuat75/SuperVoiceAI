package com.supervoice.ai

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

private val RainbowColors = listOf(
    Color(0xFFFF0000), Color(0xFFFFC800), Color(0xFF00E676),
    Color(0xFF00B0FF), Color(0xFF7C4DFF), Color(0xFFFF4081), Color(0xFFFF0000)
)
private val BarHeights = floatArrayOf(0.35f, 0.70f, 0.50f, 1.00f, 0.60f, 0.85f, 0.40f)

/**
 * Gestur transform (pan + pinch-zoom). Pan dihitung dari koordinat LAYAR (lokal + [origin])
 * supaya tidak teredam saat window ikut bergeser.
 */
fun Modifier.bubbleGestures(
    origin: () -> Offset,
    onPress: (Boolean) -> Unit,
    onDrag: (Offset) -> Unit,
    onZoom: (Float) -> Unit,
    onEnd: (moved: Boolean) -> Unit
): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        onPress(true)
        var moved = false
        var zoomed = false
        var total = Offset.Zero
        var prev: Offset? = null
        do {
            val event = awaitPointerEvent()
            val active = event.changes.filter { it.pressed }
            if (active.size >= 2) {
                zoomed = true
                prev = null
                val z = event.calculateZoom()
                if (z != 1f) onZoom(z)
            } else if (active.size == 1 && !zoomed) {
                val cur = active[0].position + origin()
                val p = prev
                if (p != null) {
                    val d = cur - p
                    total += d
                    if (!moved && total.getDistance() > viewConfiguration.touchSlop) moved = true
                    if (moved) onDrag(d)
                }
                prev = cur
            }
            event.changes.forEach { it.consume() }
        } while (event.changes.any { it.pressed })
        onPress(false)
        onEnd(moved || zoomed)
    }
}

@Composable
fun WaveBubble(
    isRecording: Boolean,
    durationMs: Int,
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    gestureModifier: Modifier = Modifier
) {
    val pressed by interactionSource.collectIsPressedAsState()
    val squish by animateFloatAsState(
        targetValue = if (pressed) 0.8f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessMedium),
        label = "squish"
    )
    val transition = key(durationMs) { rememberInfiniteTransition(label = "bubble") }
    val spinSpec = remember(durationMs) {
        infiniteRepeatable<Float>(tween(durationMs.coerceIn(1000, 5000), easing = LinearEasing), RepeatMode.Restart)
    }
    val waveSpec = remember {
        infiniteRepeatable<Float>(tween(900, easing = LinearEasing), RepeatMode.Restart)
    }
    val angle: Float by transition.animateFloat(0f, 360f, spinSpec, label = "spin")
    val phase: Float by transition.animateFloat(0f, (2 * PI).toFloat(), waveSpec, label = "wave")

    Canvas(gestureModifier.fillMaxSize().graphicsLayer { scaleX = squish; scaleY = squish }) {
        val stroke = 8.dp.toPx()
        val c = center
        val radius = size.minDimension / 2f - stroke / 2f

        rotate(degrees = angle, pivot = c) {
            drawCircle(
                brush = Brush.sweepGradient(RainbowColors, center = c),
                radius = radius,
                center = c,
                style = Stroke(width = stroke)
            )
        }

        val barColor = if (isRecording) Color(0xFFE53935) else Color(0xFF006494)
        val n = BarHeights.size
        val areaW = size.width * 0.46f
        val barW = areaW / (n * 2 - 1)
        val maxH = size.height * 0.46f
        val startX = c.x - areaW / 2f + barW / 2f
        for (i in 0 until n) {
            val scale: Float = if (isRecording) 0.35f + 0.65f * abs(sin(phase + i.toFloat() * 0.9f)) else 1f
            val h = maxH * BarHeights[i] * scale
            val x = startX + i * barW * 2f
            drawLine(
                color = barColor,
                start = Offset(x, c.y - h / 2f),
                end = Offset(x, c.y + h / 2f),
                strokeWidth = barW,
                cap = StrokeCap.Round
            )
        }
    }
}

/** Air warna-warni (radialGradient) yang menyebar mulus memenuhi layar dari titik [center]. */
@Composable
fun RippleBurst(center: Offset, durationMs: Int, onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMs.coerceIn(400, 3000), easing = LinearOutSlowInEasing))
        onFinished()
    }
    Canvas(Modifier.fillMaxSize()) {
        val p = progress.value
        val maxR = hypot(size.width, size.height)
        val r = (maxR * p).coerceAtLeast(1f)
        val a = 0.55f * (1f - p * p)
        val stops = arrayOf(
            0.00f to RainbowColors[0].copy(alpha = a),
            0.20f to RainbowColors[1].copy(alpha = a),
            0.40f to RainbowColors[2].copy(alpha = a),
            0.60f to RainbowColors[3].copy(alpha = a),
            0.80f to RainbowColors[4].copy(alpha = a * 0.8f),
            0.93f to RainbowColors[5].copy(alpha = a * 0.5f),
            1.00f to Color.Transparent
        )
        drawCircle(
            brush = Brush.radialGradient(colorStops = stops, center = center, radius = r),
            radius = r, center = center
        )
    }
}

/** Pemilik lifecycle agar ComposeView bisa jalan di dalam Service (overlay). */
class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    init {
        controller.performAttach()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() { registry.currentState = Lifecycle.State.RESUMED }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}
