package com.supervoice.ai

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.remember
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

private val RainbowColors = listOf(
    Color(0xFFFF0000), Color(0xFFFFC800), Color(0xFF00E676),
    Color(0xFF00B0FF), Color(0xFF7C4DFF), Color(0xFFFF4081), Color(0xFFFF0000)
)
/** Pengaturan air di dalam tombol saat diam (SharedPreferences "idle_*"). */
data class WaterConfig(
    val enabled: Boolean = true,
    val levelPct: Int = 55,
    val wavePct: Int = 40,
    val speedMs: Int = 3000,
    val hue: Int = 200,
    val rainbow: Boolean = false
) {
    companion object {
        fun from(p: android.content.SharedPreferences) = WaterConfig(
            enabled = p.getBoolean("idle_enabled", true),
            levelPct = p.getInt("idle_level", 55).coerceIn(20, 90),
            wavePct = p.getInt("idle_wave", 40).coerceIn(0, 100),
            speedMs = p.getInt("idle_speed_ms", 3000).coerceIn(1000, 18000),
            hue = p.getInt("idle_hue", 200).coerceIn(0, 360),
            rainbow = p.getBoolean("idle_rainbow", false)
        )
    }
}

private const val MaxBreathDepth = 0.05f

private val BarHeights = floatArrayOf(0.35f, 0.70f, 0.50f, 1.00f, 0.60f, 0.85f, 0.40f)

/**
 * Gestur transform (pan + pinch-zoom). Pan dihitung dari koordinat LAYAR (lokal + [origin])
 * supaya tidak teredam saat window ikut bergeser.
 */
fun Modifier.bubbleGestures(
    origin: () -> Offset,
    onPress: (Boolean) -> Unit,
    onDrag: (Offset) -> Unit,
    onZoom: (Float) -> Unit,
    onEnd: (moved: Boolean) -> Unit
): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        onPress(true)
        var moved = false
        var zoomed = false
        var total = Offset.Zero
        var prev: Offset? = null
        do {
            val event = awaitPointerEvent()
            val active = event.changes.filter { it.pressed }
            if (active.size >= 2) {
                zoomed = true
                prev = null
                val z = event.calculateZoom()
                if (z != 1f) onZoom(z)
            } else if (active.size == 1 && !zoomed) {
                val cur = active[0].position + origin()
                val p = prev
                if (p != null) {
                    val d = cur - p
                    total += d
                    if (!moved && total.getDistance() > viewConfiguration.touchSlop) moved = true
                    if (moved) onDrag(d)
                }
                prev = cur
            }
            event.changes.forEach { it.consume() }
        } while (event.changes.any { it.pressed })
        onPress(false)
        onEnd(moved || zoomed)
    }
}

@Composable
fun WaveBubble(
    isRecording: Boolean,
    durationMs: Int,
    pressDepthPct: Int = 20,
    water: WaterConfig = WaterConfig(),
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    gestureModifier: Modifier = Modifier,
    animProgress: Float = 0f
) {
    val pressed by interactionSource.collectIsPressedAsState()
    val squish by animateFloatAsState(
        targetValue = if (pressed) 1f - pressDepthPct.coerceIn(0, 60) / 100f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "squish"
    )
    val idleWeight by animateFloatAsState(if (pressed) 0f else 1f, tween(200), label = "idleWeight")
    val waterRef by rememberUpdatedState(water)
    val level by animateFloatAsState(water.levelPct / 100f, tween(500), label = "wLevel")
    val waveAmp by animateFloatAsState(water.wavePct / 100f, tween(500), label = "wAmp")
    val hueTarget by animateFloatAsState(water.hue.toFloat(), tween(500), label = "wHue")
    val fillIn by animateFloatAsState(if (water.enabled) 1f else 0f, tween(700, easing = LinearOutSlowInEasing), label = "wFill")
    var waterPhase by remember { mutableFloatStateOf(0f) }
    var hueDrift by remember { mutableFloatStateOf(0f) }
    // Sudut putar diintegrasikan per-frame: ganti kecepatan (slider) = lanjut mulus, tidak restart/berhenti
    val speedMs by rememberUpdatedState(durationMs)
    var angle by remember { mutableFloatStateOf(0f) }
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dtMs = (now - last) / 1_000_000f
            last = now
            angle = (angle + 360f * dtMs / speedMs.coerceIn(1000, 15000)) % 360f
            phase = (phase + (2 * PI).toFloat() * dtMs / 900f) % (2 * PI).toFloat()
            val w = waterRef
            waterPhase = (waterPhase + (2 * PI).toFloat() * dtMs / w.speedMs.coerceIn(1000, 18000)) % (2 * PI).toFloat()
            if (w.rainbow) hueDrift = (hueDrift + 360f * dtMs / 12000f) % 360f
        }
    }
    // animProgress datang dari root Box (FloatingAudioService): skala + nyala warna memakai nilai yang sama
    val fit = 1f / (1f + MaxBreathDepth)

    Canvas(gestureModifier.fillMaxSize().graphicsLayer {
        val s = squish * fit
        scaleX = s
        scaleY = s
    }) {
        val stroke = 8.dp.toPx()
        val c = center
        val radius = size.minDimension / 2f - stroke / 2f

        if (fillIn > 0.01f) {
            val inner = radius - stroke / 2f
            val clip = Path().apply { addOval(Rect(c.x - inner, c.y - inner, c.x + inner, c.y + inner)) }
            val baseLevel = level.coerceIn(0.05f, 0.95f)
            val surfaceY = c.y + inner - 2f * inner * baseLevel
            val amp = inner * 0.16f * waveAmp * (0.4f + 0.6f * idleWeight)
            val twoPi = (2 * PI).toFloat()
            val hue = if (water.rainbow) (hueTarget + hueDrift) % 360f else hueTarget
            fun col(h: Float, s: Float, v: Float, a: Float) = Color.hsv(((h % 360f) + 360f) % 360f, s, v, a * fillIn)
            val top = c.y - inner
            val bottom = c.y + inner
            val fillBack: Brush
            val fillFront: Brush
            if (water.rainbow) {
                fillBack = Brush.linearGradient(
                    listOf(col(hue + 40f, 0.6f, 1f, 0.45f), col(hue + 120f, 0.7f, 0.9f, 0.45f)),
                    Offset(c.x - inner, top), Offset(c.x + inner, bottom))
                fillFront = Brush.linearGradient(
                    listOf(col(hue, 0.7f, 1f, 0.8f), col(hue + 70f, 0.85f, 0.85f, 0.85f)),
                    Offset(c.x - inner, top), Offset(c.x + inner, bottom))
            } else {
                fillBack = Brush.verticalGradient(
                    listOf(col(hue, 0.45f, 1f, 0.40f), col(hue, 0.7f, 0.85f, 0.50f)), top, bottom)
                fillFront = Brush.verticalGradient(
                    listOf(col(hue, 0.55f, 1f, 0.75f), col(hue, 0.9f, 0.70f, 0.90f)), top, bottom)
            }
            fun wave(freq: Float, ph: Float, a: Float, tilt: Float): Path {
                val p = Path()
                val x0 = c.x - inner
                val steps = 48
                p.moveTo(x0, bottom + 2f)
                for (i in 0..steps) {
                    val fx = i / steps.toFloat()
                    val x = x0 + fx * 2f * inner
                    val y = surfaceY + a * sin(fx * twoPi * freq + ph) + tilt * (fx - 0.5f) * 2f
                    p.lineTo(x, y)
                }
                p.lineTo(c.x + inner, bottom + 2f)
                p.close()
                return p
            }
            val slosh = amp * 0.9f * sin(waterPhase * 0.5f)
            clipPath(clip) {
                drawPath(wave(1.2f, -waterPhase + 1.7f, amp * 0.8f, -slosh), fillBack)
                drawPath(wave(1.0f, waterPhase, amp, slosh), fillFront)
            }
        }

        rotate(degrees = angle, pivot = c) {
            drawCircle(
                brush = Brush.sweepGradient(RainbowColors, center = c),
                radius = radius,
                center = c,
                alpha = 0.3f + (animProgress * 0.5f),
                style = Stroke(width = stroke)
            )
        }

        val barColor = if (isRecording) Color(0xFFE53935) else Color(0xFF006494)
        val n = BarHeights.size
        val areaW = size.width * 0.46f
        val barW = areaW / (n * 2 - 1)
        val maxH = size.height * 0.46f
        val startX = c.x - areaW / 2f + barW / 2f
        for (i in 0 until n) {
            val scale: Float = if (isRecording) 0.35f + 0.65f * abs(sin(phase + i.toFloat() * 0.9f)) else 1f
            val h = maxH * BarHeights[i] * scale
            val x = startX + i * barW * 2f
            drawLine(
                color = barColor,
                start = Offset(x, c.y - h / 2f),
                end = Offset(x, c.y + h / 2f),
                strokeWidth = barW,
                cap = StrokeCap.Round
            )
        }
    }
}

/** Air warna-warni (radialGradient) yang menyebar mulus memenuhi layar dari titik [center]. */
@Composable
fun RippleBurst(center: Offset, durationMs: Int, amountPct: Int, onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMs.coerceIn(400, 9000), easing = LinearOutSlowInEasing))
        onFinished()
    }
    Canvas(Modifier.fillMaxSize()) {
        val p = progress.value
        val maxR = hypot(size.width, size.height)
        val amt = amountPct.coerceIn(10, 100)
        val reach = (amt / 55f).coerceIn(0.2f, 1f)
        val r = (maxR * reach * p).coerceAtLeast(1f)
        val a = (amt / 100f) * (1f - p * p)
        val stops = arrayOf(
            0.00f to RainbowColors[0].copy(alpha = a),
            0.20f to RainbowColors[1].copy(alpha = a),
            0.40f to RainbowColors[2].copy(alpha = a),
            0.60f to RainbowColors[3].copy(alpha = a),
            0.80f to RainbowColors[4].copy(alpha = a * 0.8f),
            0.93f to RainbowColors[5].copy(alpha = a * 0.5f),
            1.00f to Color.Transparent
        )
        drawCircle(
            brush = Brush.radialGradient(colorStops = stops, center = center, radius = r),
            radius = r, center = center
        )
    }
}

/** Pemilik lifecycle agar ComposeView bisa jalan di dalam Service (overlay). */
class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    init {
        controller.performAttach()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() { registry.currentState = Lifecycle.State.RESUMED }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}
