package com.supervoice.ai

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private val RainbowColors = listOf(
    Color(0xFFFF0000), Color(0xFFFFC800), Color(0xFF00E676),
    Color(0xFF00B0FF), Color(0xFF7C4DFF), Color(0xFFFF4081), Color(0xFFFF0000)
)
private val BarHeights = floatArrayOf(0.35f, 0.70f, 0.50f, 1.00f, 0.60f, 0.85f, 0.40f)

@Composable
fun WaveBubble(isRecording: Boolean, durationMs: Int) {
    val transition = rememberInfiniteTransition(label = "bubble")
    val spinSpec = remember(durationMs) {
        infiniteRepeatable<Float>(tween(durationMs.coerceIn(1000, 5000), easing = LinearEasing), RepeatMode.Restart)
    }
    val waveSpec = remember {
        infiniteRepeatable<Float>(tween(900, easing = LinearEasing), RepeatMode.Restart)
    }
    val angle by transition.animateFloat(0f, 360f, spinSpec, label = "spin")
    val phase by transition.animateFloat(0f, (2 * PI).toFloat(), waveSpec, label = "wave")

    Canvas(Modifier.fillMaxSize()) {
        val stroke = 3.dp.toPx()
        val c = center
        val radius = size.minDimension / 2f - stroke / 2f

        rotate(degrees = angle, pivot = c) {
            drawCircle(
                brush = Brush.sweepGradient(RainbowColors, center = c),
                radius = radius,
                center = c,
                style = Stroke(width = stroke)
            )
        }

        val barColor = if (isRecording) Color(0xFFE53935) else Color(0xFF006494)
        val n = BarHeights.size
        val areaW = size.width * 0.52f
        val barW = areaW / (n * 2 - 1)
        val maxH = size.height * 0.46f
        val startX = c.x - areaW / 2f + barW / 2f
        for (i in 0 until n) {
            val scale = if (isRecording) 0.35f + 0.65f * abs(sin(phase + i * 0.9f)) else 1f
            val h = maxH * BarHeights[i] * scale
            val x = startX + i * barW * 2f
            drawLine(
                color = barColor,
                start = Offset(x, c.y - h / 2f),
                end = Offset(x, c.y + h / 2f),
                strokeWidth = barW,
                cap = StrokeCap.Round
            )
        }
    }
}

/** Pemilik lifecycle agar ComposeView bisa jalan di dalam Service (overlay). */
class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    init {
        controller.performAttach()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() { registry.currentState = Lifecycle.State.RESUMED }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}
