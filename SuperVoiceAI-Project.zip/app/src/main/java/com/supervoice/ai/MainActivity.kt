package com.supervoice.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.supervoice.ai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (!audioGranted) {
            Toast.makeText(this, "Izin mikrofon wajib diaktifkan!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSettings()
        checkAndRequestPermissions()

        binding.btnSave.setOnClickListener {
            saveSettings()
        }

        binding.btnStartFloating.setOnClickListener {
            startFloatingWidget()
        }

        binding.btnStopFloating.setOnClickListener {
            stopService(Intent(this, FloatingAudioService::class.java))
            Toast.makeText(this, "Widget mengambang dimatikan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        binding.etApiKey.setText(prefs.getString("api_key", ""))
        binding.rgProvider.check(if (prefs.getBoolean("is_groq", true)) R.id.rbGroq else R.id.rbOpenAI)
        binding.switchAutoCorrect.isChecked = prefs.getBoolean("auto_correct", true)
    }

    private fun saveSettings() {
        val apiKey = binding.etApiKey.text.toString().trim()
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "API Key tidak boleh kosong!", Toast.LENGTH_SHORT).show()
            return
        }

        val isGroq = binding.rgProvider.checkedRadioButtonId == R.id.rbGroq
        val autoCorrect = binding.switchAutoCorrect.isChecked

        getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
            .putString("api_key", apiKey)
            .putBoolean("is_groq", isGroq)
            .putBoolean("auto_correct", autoCorrect)
            .apply()

        Toast.makeText(this, "Pengaturan & API Key Berhasil Disimpan!", Toast.LENGTH_SHORT).show()
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun startFloatingWidget() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Berikan izin 'Tampilkan di atas aplikasi lain'", Toast.LENGTH_LONG).show()
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            checkAndRequestPermissions()
            return
        }

        val serviceIntent = Intent(this, FloatingAudioService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "Tombol rekam melayang aktif!", Toast.LENGTH_SHORT).show()
        finish() // Menutup activity agar pengguna langsung bisa menggunakan overlay
    }
}
