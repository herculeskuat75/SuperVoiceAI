package com.supervoice.ai

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.supervoice.ai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (!audioGranted) {
            Toast.makeText(this, "Izin mikrofon wajib diaktifkan!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSettings()
        checkAndRequestPermissions()

        binding.sliderRainbow.addOnChangeListener { _, value, _ ->
            val ms = value.toInt()
            binding.tvRainbowLabel.text = "Kecepatan Putar Rainbow: $ms ms"
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
                .putInt("rainbow_duration_ms", ms)
                .apply()
        }

        binding.sliderWater.addOnChangeListener { _, value, _ ->
            val ms = value.toInt()
            binding.tvWaterLabel.text = "Kecepatan Animasi Air: $ms ms"
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
                .putInt("water_duration_ms", ms)
                .apply()
        }

        binding.switchOutputMode.setOnCheckedChangeListener { _, checked ->
            updateOutputLabel(checked)
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
                .putBoolean("output_type_mode", checked).apply()
            if (checked && !isAccessibilityEnabled()) {
                enableAccessibilityAuto()
            }
        }

        binding.btnSave.setOnClickListener {
            saveSettings()
        }

        binding.btnStartFloating.setOnClickListener {
            startFloatingWidget()
        }

        binding.btnStopFloating.setOnClickListener {
            stopService(Intent(this, FloatingAudioService::class.java))
            Toast.makeText(this, "Widget mengambang dimatikan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun serviceComponent(): String =
        ComponentName(this, TypingAccessibilityService::class.java).flattenToString()

    private fun isAccessibilityEnabled(): Boolean {
        if (TypingAccessibilityService.instance != null) return true
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val target = serviceComponent()
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.id == target || it.id == target.replace("/.", "/") ||
                it.resolveInfo?.serviceInfo?.let { si -> si.packageName == packageName &&
                    si.name == TypingAccessibilityService::class.java.name } == true }
    }

    private fun runSu(cmd: String): String? = try {
        val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val out = proc.inputStream.bufferedReader().readText().trim()
        if (proc.waitFor() == 0) out else null
    } catch (e: Exception) { null }

    private fun enableAccessibilityAuto() {
        val svc = serviceComponent()
        Thread {
            var ok = false
            val current = runSu("settings get secure enabled_accessibility_services")
            if (current != null) {
                val list = current.split(":").filter { it.isNotBlank() && it != "null" }.toMutableList()
                if (!list.contains(svc)) list.add(svc)
                val joined = list.joinToString(":")
                // Setara: su -c settings put secure enabled_accessibility_services <package>/<service>
                val r1 = runSu("settings put secure enabled_accessibility_services $joined")
                val r2 = runSu("settings put secure accessibility_enabled 1")
                if (r1 != null && r2 != null) {
                    for (i in 0 until 10) {
                        Thread.sleep(300)
                        if (isAccessibilityEnabled()) { ok = true; break }
                    }
                }
            }
            runOnUiThread {
                if (ok) {
                    Toast.makeText(this, "Aksesibilitas aktif otomatis (Root)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Aktifkan 'Super Voice AI' di Aksesibilitas agar bisa mengetik otomatis", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        }.start()
    }

    private fun updateOutputLabel(typeMode: Boolean) {
        binding.switchOutputMode.text =
            if (typeMode) "Mode Output: Ketik Otomatis" else "Mode Output: Salin ke Clipboard"
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        binding.etApiKey.setText(prefs.getString("api_key", ""))
        binding.rgProvider.check(if (prefs.getBoolean("is_groq", true)) R.id.rbGroq else R.id.rbOpenAI)
        binding.switchAutoCorrect.isChecked = prefs.getBoolean("auto_correct", true)
        val typeMode = prefs.getBoolean("output_type_mode", false)
        binding.switchOutputMode.isChecked = typeMode
        updateOutputLabel(typeMode)
        val ms = (Math.round(prefs.getInt("rainbow_duration_ms", 3000) / 100f) * 100).coerceIn(1000, 5000)
        binding.sliderRainbow.value = ms.toFloat()
        binding.tvRainbowLabel.text = "Kecepatan Putar Rainbow: $ms ms"
        val wms = (Math.round(prefs.getInt("water_duration_ms", 1200) / 100f) * 100).coerceIn(400, 3000)
        binding.sliderWater.value = wms.toFloat()
        binding.tvWaterLabel.text = "Kecepatan Animasi Air: $wms ms"
    }

    private fun saveSettings() {
        val apiKey = binding.etApiKey.text.toString().trim()
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "API Key tidak boleh kosong!", Toast.LENGTH_SHORT).show()
            return
        }

        val isGroq = binding.rgProvider.checkedRadioButtonId == R.id.rbGroq
        val autoCorrect = binding.switchAutoCorrect.isChecked

        getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
            .putString("api_key", apiKey)
            .putBoolean("is_groq", isGroq)
            .putBoolean("auto_correct", autoCorrect)
            .putBoolean("output_type_mode", binding.switchOutputMode.isChecked)
            .putInt("rainbow_duration_ms", binding.sliderRainbow.value.toInt())
            .putInt("water_duration_ms", binding.sliderWater.value.toInt())
            .apply()

        Toast.makeText(this, "Pengaturan & API Key Berhasil Disimpan!", Toast.LENGTH_SHORT).show()
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun startFloatingWidget() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Berikan izin 'Tampilkan di atas aplikasi lain'", Toast.LENGTH_LONG).show()
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            checkAndRequestPermissions()
            return
        }

        val serviceIntent = Intent(this, FloatingAudioService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "Tombol rekam melayang aktif!", Toast.LENGTH_SHORT).show()
        finish() // Menutup activity agar pengguna langsung bisa menggunakan overlay
    }
}
