package com.supervoice.ai

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.google.android.material.slider.Slider
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.graphics.Rect
import android.view.ViewTreeObserver
import android.widget.TextView
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.text.Editable
import android.text.TextWatcher
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.supervoice.ai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    /** Level slider 0..100 -> derajat/detik (kuadratik). 0 = diam, 100 = 3600°/dtk (10 putaran/dtk, ~60°/frame @60Hz). */
    private fun rainbowDpsFromLevel(v: Float): Int {
        val r = (v / 100f).coerceIn(0f, 1f)
        return Math.round(3600f * r * r)
    }
    private fun rainbowLabel(v: Float, dps: Int): String =
        if (v <= 0f) "Kecepatan Putar Rainbow: Diam" else "Kecepatan Putar Rainbow: $dps°/dtk"

    private lateinit var binding: ActivityMainBinding

    // ---- Deteksi keyboard (WindowInsetsCompat + fallback GlobalLayout) ----
    private var keyboardVisible = false
    private var insetsReported = false
    private var layoutListener: ViewTreeObserver.OnGlobalLayoutListener? = null

    /** Satu-satunya jalur: dipanggil oleh insets maupun fallback. */
    private fun onKeyboardVisibilityChanged(visible: Boolean) {
        if (visible == keyboardVisible) return
        keyboardVisible = visible
        KeyboardState.visible = visible
        KeyboardState.listener?.invoke(visible)
    }

    private fun setupKeyboardDetection() {
        val root = binding.root
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            insetsReported = true
            onKeyboardVisibilityChanged(insets.isVisible(WindowInsetsCompat.Type.ime()))
            ViewCompat.onApplyWindowInsets(v, insets)
        }
        ViewCompat.requestApplyInsets(root)
        val listener = ViewTreeObserver.OnGlobalLayoutListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && insetsReported) return@OnGlobalLayoutListener
            val r = Rect()
            root.getWindowVisibleDisplayFrame(r)
            val diffDp = (root.rootView.height - r.bottom) / resources.displayMetrics.density
            onKeyboardVisibilityChanged(diffDp > 200f)
        }
        layoutListener = listener
        root.viewTreeObserver.addOnGlobalLayoutListener(listener)
    }

    override fun onDestroy() {
        layoutListener?.let {
            if (binding.root.viewTreeObserver.isAlive) binding.root.viewTreeObserver.removeOnGlobalLayoutListener(it)
        }
        layoutListener = null
        KeyboardState.visible = false
        super.onDestroy()
    }
    private var hasOverlayPermission = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (!audioGranted) {
            Toast.makeText(this, "Izin mikrofon wajib diaktifkan!", Toast.LENGTH_SHORT).show()
        } else {
            autoStartFloating()
        }
    }

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val bmp = contentResolver.openInputStream(uri).use { ins ->
                android.graphics.BitmapFactory.decodeStream(ins)
            } ?: throw Exception("decode gagal")
            val side = minOf(bmp.width, bmp.height)
            val sq = android.graphics.Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val out = if (side > 512) android.graphics.Bitmap.createScaledBitmap(sq, 512, 512, true) else sq
            java.io.FileOutputStream(java.io.File(filesDir, "bubble_center.png")).use {
                out.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
            }
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
                .putLong("center_image_ver", System.currentTimeMillis()).apply()
            Toast.makeText(this, "Gambar tengah tombol diganti", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupKeyboardDetection()

        loadSettings()
        checkAndRequestPermissions()
        hasOverlayPermission = Settings.canDrawOverlays(this)
        if (!hasOverlayPermission) grantOverlayViaRoot() else autoStartFloating()

        binding.sliderRainbow.addOnChangeListener { _, value, _ ->
            val dps = rainbowDpsFromLevel(value)
            binding.tvRainbowLabel.text = rainbowLabel(value, dps)
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
                .putInt("rainbow_speed_dps", dps)
                .apply()
        }

        binding.sliderWater.addOnChangeListener { _, value, _ ->
            val ms = (400 + 9000 - value).toInt()
            binding.tvWaterLabel.text = "Kecepatan Animasi Air: $ms ms"
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
                .putInt("water_duration_ms", ms)
                .apply()
        }

        binding.sliderPressDepth.addOnChangeListener { _, v, _ ->
            binding.tvPressDepth.text = "Kedalaman Tombol Masuk (saat ditekan): ${v.toInt()}%"
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit().putInt("press_depth", v.toInt()).apply()
        }
        binding.sliderWaterAmount.addOnChangeListener { _, v, _ ->
            binding.tvWaterAmount.text = "Banyak Warna Keluar: ${v.toInt()}%"
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit().putInt("water_amount", v.toInt()).apply()
        }
        binding.sliderGlowReach.addOnChangeListener { _, v, _ ->
            binding.tvGlowReach.text = if (v.toInt() == 0) "Jangkauan Warna Saat Diam: Bawaan" else if (v.toInt() >= 100) "Jangkauan Warna Saat Diam: Seluruh Layar" else "Jangkauan Warna Saat Diam: ${v.toInt()}%"
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit().putInt("glow_reach", v.toInt()).apply()
        }
        binding.sliderWaterReach.addOnChangeListener { _, v, _ ->
            binding.tvWaterReach.text = if (v.toInt() == 0) "Jangkauan Warna ke Layar: Bawaan" else if (v.toInt() >= 100) "Jangkauan Warna ke Layar: Seluruh Layar" else "Jangkauan Warna ke Layar: ${v.toInt()}%"
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit().putInt("water_reach", v.toInt()).apply()
        }

        fun prefs() = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        binding.switchIdleWater.setOnCheckedChangeListener { _, c -> prefs().edit().putBoolean("idle_enabled", c).apply() }
        binding.switchIdleRainbow.setOnCheckedChangeListener { _, c ->
            prefs().edit().putBoolean("idle_rainbow", c).apply()
            binding.sliderIdleHue.isEnabled = !c
        }
        binding.sliderIdleLevel.addOnChangeListener { _, v, _ ->
            binding.tvIdleLevel.text = "Kedalaman Air: ${v.toInt()}%"
            prefs().edit().putInt("idle_level", v.toInt()).apply()
        }
        binding.sliderIdleWave.addOnChangeListener { _, v, _ ->
            binding.tvIdleWave.text = "Tinggi Gelombang: ${v.toInt()}%"
            prefs().edit().putInt("idle_wave", v.toInt()).apply()
        }
        binding.sliderIdleSpeed.addOnChangeListener { _, v, _ ->
            val ms = (1000 + 18000 - v).toInt()
            binding.tvIdleSpeed.text = "Kecepatan Gerak Air: $ms ms"
            prefs().edit().putInt("idle_speed_ms", ms).apply()
        }
        binding.sliderIdleHue.addOnChangeListener { _, v, _ ->
            binding.tvIdleHue.text = "Warna Air: ${v.toInt()}°"
            binding.viewIdleHue.setBackgroundColor(android.graphics.Color.HSVToColor(floatArrayOf(v, 0.8f, 0.9f)))
            prefs().edit().putInt("idle_hue", v.toInt()).apply()
        }

        run {
            val par = binding.sliderPressDepth.parent as android.widget.LinearLayout
            fun addRow(title: String, from: Float, to: Float, step: Float, init: Float, onChange: (Slider, TextView, Float) -> Unit) {
                val tv = TextView(this).apply {
                    setTypeface(typeface, android.graphics.Typeface.BOLD); textSize = 15f
                    layoutParams = android.widget.LinearLayout.LayoutParams(-2, -2).apply { topMargin = (16 * resources.displayMetrics.density).toInt() }
                }
                val sl = Slider(this).apply {
                    layoutParams = android.widget.LinearLayout.LayoutParams(-1, -2)
                    valueFrom = from; valueTo = to; stepSize = step; value = init
                }
                sl.addOnChangeListener { s, v, _ -> onChange(s, tv, v) }
                par.addView(tv); par.addView(sl)
                onChange(sl, tv, init)
            }
            val bp = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
            val bms = (Math.round(bp.getInt("breath_speed_ms", 3000) / 100f) * 100).coerceIn(0, 5000)
            addRow("Kecepatan Napas", 0f, 5000f, 100f, if (bms <= 0) 0f else (5100 - bms).coerceIn(100, 5000).toFloat()) { _, tv, v ->
                val ms = if (v <= 0f) 0 else (5100 - v.toInt())
                tv.text = if (ms == 0) "Kecepatan Napas: Diam" else "Kecepatan Napas: $ms ms"
                bp.edit().putInt("breath_speed_ms", ms).apply()
            }
            val bd = bp.getInt("breath_depth", 5).coerceIn(0, 100)
            addRow("Kedalaman Napas", 0f, 100f, 1f, bd.toFloat()) { _, tv, v ->
                tv.text = "Kedalaman Napas: ${v.toInt()}%"
                bp.edit().putInt("breath_depth", v.toInt()).apply()
            }
        }

        binding.switchOutputMode.setOnCheckedChangeListener { _, checked ->
            updateOutputLabel(checked)
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
                .putBoolean("output_type_mode", checked).apply()
            if (checked && !isAccessibilityEnabled()) {
                enableAccessibilityAuto()
            }
        }

        setupAutoSave()

        binding.btnPickCenterImage.setOnClickListener { pickImageLauncher.launch("image/*") }
        binding.btnClearCenterImage.setOnClickListener {
            try { java.io.File(filesDir, "bubble_center.png").delete() } catch (_: Exception) {}
            getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
                .putLong("center_image_ver", System.currentTimeMillis()).apply()
            Toast.makeText(this, "Gambar tengah dikembalikan ke default", Toast.LENGTH_SHORT).show()
        }

        binding.btnSave.setOnClickListener {
            saveSettings()
        }

        binding.btnStartFloating.setOnClickListener {
            startFloatingWidget()
        }

        binding.btnStopFloating.setOnClickListener {
            stopService(Intent(this, FloatingAudioService::class.java))
            Toast.makeText(this, "Widget mengambang dimatikan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun serviceComponent(): String =
        ComponentName(this, TypingAccessibilityService::class.java).flattenToString()

    private fun isAccessibilityEnabled(): Boolean {
        if (TypingAccessibilityService.instance != null) return true
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val target = serviceComponent()
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.id == target || it.id == target.replace("/.", "/") ||
                it.resolveInfo?.serviceInfo?.let { si -> si.packageName == packageName &&
                    si.name == TypingAccessibilityService::class.java.name } == true }
    }

    private fun runSu(cmd: String): String? = try {
        val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val out = proc.inputStream.bufferedReader().readText().trim()
        if (proc.waitFor() == 0) out else null
    } catch (e: Exception) { null }

    private fun enableAccessibilityAuto() {
        val svc = serviceComponent()
        Thread {
            var ok = false
            val current = runSu("settings get secure enabled_accessibility_services")
            if (current != null) {
                val list = current.split(":").filter { it.isNotBlank() && it != "null" }.toMutableList()
                if (!list.contains(svc)) list.add(svc)
                val joined = list.joinToString(":")
                // Setara: su -c settings put secure enabled_accessibility_services <package>/<service>
                val r1 = runSu("settings put secure enabled_accessibility_services $joined")
                val r2 = runSu("settings put secure accessibility_enabled 1")
                if (r1 != null && r2 != null) {
                    for (i in 0 until 10) {
                        Thread.sleep(300)
                        if (isAccessibilityEnabled()) { ok = true; break }
                    }
                }
            }
            runOnUiThread {
                if (ok) {
                    Toast.makeText(this, "Aksesibilitas aktif otomatis (Root)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Aktifkan 'Super Voice AI' di Aksesibilitas agar bisa mengetik otomatis", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        }.start()
    }

    private fun updateOutputLabel(typeMode: Boolean) {
        binding.switchOutputMode.text =
            if (typeMode) "Mode Output: Ketik Otomatis" else "Mode Output: Salin ke Clipboard"
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)
        binding.etApiKey.setText(prefs.getString("api_key", ""))
        binding.etApiKeyKoreksi.setText(prefs.getString("api_key_koreksi", ""))
        binding.rgProvider.check(if (prefs.getBoolean("is_groq", true)) R.id.rbGroq else R.id.rbOpenAI)
        binding.switchAutoCorrect.isChecked = prefs.getBoolean("auto_correct", true)
        val typeMode = prefs.getBoolean("output_type_mode", false)
        binding.switchOutputMode.isChecked = typeMode
        updateOutputLabel(typeMode)
        val dpsSaved = if (prefs.contains("rainbow_speed_dps")) prefs.getInt("rainbow_speed_dps", 120)
            else 360000 / prefs.getInt("rainbow_duration_ms", 3000).coerceIn(1000, 15000)
        val lvl = Math.round(100f * kotlin.math.sqrt(dpsSaved.coerceIn(0, 3600) / 3600f)).toFloat()
        binding.sliderRainbow.valueFrom = 0f
        binding.sliderRainbow.valueTo = 100f
        binding.sliderRainbow.stepSize = 1f
        binding.sliderRainbow.value = lvl
        binding.tvRainbowLabel.text = rainbowLabel(lvl, rainbowDpsFromLevel(lvl))
        val wms = (Math.round(prefs.getInt("water_duration_ms", 1200) / 100f) * 100).coerceIn(400, 9000)
        binding.sliderWater.valueTo = 9000f
        binding.sliderWater.value = (400 + 9000 - wms).toFloat()
        binding.tvWaterLabel.text = "Kecepatan Animasi Air: $wms ms"
        val pd = (Math.round(prefs.getInt("press_depth", 20) / 5f) * 5).coerceIn(0, 60)
        binding.sliderPressDepth.value = pd.toFloat()
        binding.tvPressDepth.text = "Kedalaman Tombol Masuk (saat ditekan): $pd%"
        val wa = (Math.round(prefs.getInt("water_amount", 55) / 5f) * 5).coerceIn(10, 100)
        binding.sliderWaterAmount.value = wa.toFloat()
        binding.tvWaterAmount.text = "Banyak Warna Keluar: $wa%"
        val gr = (Math.round(prefs.getInt("glow_reach", 0) / 5f) * 5).coerceIn(0, 100)
        binding.sliderGlowReach.value = gr.toFloat()
        binding.tvGlowReach.text = if (gr == 0) "Jangkauan Warna Saat Diam: Bawaan" else if (gr >= 100) "Jangkauan Warna Saat Diam: Seluruh Layar" else "Jangkauan Warna Saat Diam: $gr%"
        val wr = (Math.round(prefs.getInt("water_reach", 0) / 5f) * 5).coerceIn(0, 100)
        binding.sliderWaterReach.value = wr.toFloat()
        binding.tvWaterReach.text = if (wr == 0) "Jangkauan Warna ke Layar: Bawaan" else if (wr >= 100) "Jangkauan Warna ke Layar: Seluruh Layar" else "Jangkauan Warna ke Layar: $wr%"
        fun snap(v: Int, from: Int, to: Int, step: Int) =
            (from + Math.round((v - from) / step.toFloat()) * step).coerceIn(from, to)
        binding.switchIdleWater.isChecked = prefs.getBoolean("idle_enabled", true)
        binding.switchIdleRainbow.isChecked = prefs.getBoolean("idle_rainbow", false)
        val lv = snap(prefs.getInt("idle_level", 55), 20, 90, 5)
        binding.sliderIdleLevel.value = lv.toFloat()
        binding.tvIdleLevel.text = "Kedalaman Air: $lv%"
        val wv = snap(prefs.getInt("idle_wave", 40), 0, 100, 5)
        binding.sliderIdleWave.value = wv.toFloat()
        binding.tvIdleWave.text = "Tinggi Gelombang: $wv%"
        val sp = snap(prefs.getInt("idle_speed_ms", 3000), 1000, 18000, 100)
        binding.sliderIdleSpeed.valueTo = 18000f
        binding.sliderIdleSpeed.value = (1000 + 18000 - sp).toFloat()
        binding.tvIdleSpeed.text = "Kecepatan Gerak Air: $sp ms"
        val hu = snap(prefs.getInt("idle_hue", 200), 0, 360, 5)
        binding.sliderIdleHue.value = hu.toFloat()
        binding.tvIdleHue.text = "Warna Air: $hu°"
        binding.viewIdleHue.setBackgroundColor(android.graphics.Color.HSVToColor(floatArrayOf(hu.toFloat(), 0.8f, 0.9f)))
        binding.sliderIdleHue.isEnabled = !binding.switchIdleRainbow.isChecked
    }

    private fun sp() = getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE)

    /** Simpan otomatis API Key & engine ke SharedPreferences (hanya putString/putBoolean + apply, tanpa clear). */
    private fun setupAutoSave() {
        val engines = listOf("Groq", "Gemini")
        binding.spCorrectionEngine.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, engines)
        val saved = sp().getString("correction_engine", "Groq") ?: "Groq"
        binding.spCorrectionEngine.setSelection(engines.indexOf(saved).coerceAtLeast(0), false)
        binding.spCorrectionEngine.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                val editor = sp().edit()
                editor.putString("correction_engine", engines[pos])
                editor.apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        fun watch(et: android.widget.EditText, key: String) {
            et.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val editor = sp().edit()
                    editor.putString(key, s?.toString()?.trim().orEmpty())
                    editor.apply()
                }
            })
        }
        watch(binding.etApiKey, "api_key")
        watch(binding.etApiKeyKoreksi, "api_key_koreksi")
        binding.rgProvider.setOnCheckedChangeListener { _, id ->
            val editor = sp().edit()
            editor.putBoolean("is_groq", id == R.id.rbGroq)
            editor.apply()
        }
        binding.switchAutoCorrect.setOnCheckedChangeListener { _, c ->
            val editor = sp().edit()
            editor.putBoolean("auto_correct", c)
            editor.apply()
        }
    }

    private fun saveSettings() {
        val apiKeyTranskripsi = binding.etApiKey.text.toString().trim()
        val apiKeyKoreksi = binding.etApiKeyKoreksi.text.toString().trim()
        if (apiKeyTranskripsi.isEmpty()) {
            Toast.makeText(this, "API Key tidak boleh kosong!", Toast.LENGTH_SHORT).show()
            return
        }

        val isGroq = binding.rgProvider.checkedRadioButtonId == R.id.rbGroq
        val autoCorrect = binding.switchAutoCorrect.isChecked

        getSharedPreferences("SuperVoicePrefs", Context.MODE_PRIVATE).edit()
            .putString("api_key", apiKeyTranskripsi)
            .putString("api_key_koreksi", apiKeyKoreksi)
            .putBoolean("is_groq", isGroq)
            .putBoolean("auto_correct", autoCorrect)
            .putBoolean("output_type_mode", binding.switchOutputMode.isChecked)
            .putInt("rainbow_speed_dps", rainbowDpsFromLevel(binding.sliderRainbow.value))
            .putInt("water_duration_ms", 9400 - binding.sliderWater.value.toInt())
            .apply()

        Toast.makeText(this, "Pengaturan & API Key Berhasil Disimpan!", Toast.LENGTH_SHORT).show()
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun grantOverlayViaRoot() {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "appops set $packageName SYSTEM_ALERT_WINDOW allow"))
                    p.waitFor() == 0
                } catch (e: Exception) { false }
            }
            if (ok || Settings.canDrawOverlays(this@MainActivity)) {
                hasOverlayPermission = true
                autoStartFloating()
            }
        }
    }

    /** Otomatis jalankan FloatingService di background bila izin overlay & mikrofon sudah ada. */
    private fun autoStartFloating() {
        if (!(hasOverlayPermission || Settings.canDrawOverlays(this))) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        hasOverlayPermission = true
        try {
            ContextCompat.startForegroundService(this, Intent(this, FloatingAudioService::class.java))
        } catch (_: Exception) {}
    }

    private fun startFloatingWidget() {
        if (!hasOverlayPermission && !Settings.canDrawOverlays(this)) {
            grantOverlayViaRoot()
            Toast.makeText(this, "Izin Overlay belum aktif (butuh Root)", Toast.LENGTH_SHORT).show()
            return
        }
        hasOverlayPermission = true

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            checkAndRequestPermissions()
            return
        }

        val serviceIntent = Intent(this, FloatingAudioService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "Tombol rekam melayang aktif!", Toast.LENGTH_SHORT).show()
        finish() // Menutup activity agar pengguna langsung bisa menggunakan overlay
    }
}
